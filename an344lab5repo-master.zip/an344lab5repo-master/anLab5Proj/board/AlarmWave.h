/*
 * AlarmWave.h
 *
 *  Created on: Nov 15, 2021
 *      Author: ASUS
 */

#ifndef ALARMWAVE_H_
#define ALARMWAVE_H_



#endif /* ALARMWAVE_H_ */
void AlarmWaveInit(void);
void AlarmWaveSetMode(INT8U Mode);
